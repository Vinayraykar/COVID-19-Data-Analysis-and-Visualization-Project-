```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import mysql.connector as msc

import warnings
warnings.filterwarnings('ignore')
```


```python

from sqlalchemy import create_engine

# 1. Define your database connection

connection_string = "mysql+mysqlconnector://root:Vinay%402002@127.0.0.1/Covid_19_Database"
engine = create_engine(connection_string)

# 2. Define the folder and files to process
folder_path = "C:/Users/Vinay Raykar/OneDrive/Documents/My Courses/Side Project/Covid 19 Dataset/Corona data files"
csv_files = [
    ('worldometer_coronavirus_daily_data.csv', 'daily_data'),
    ('worldometer_coronavirus_summary_data.csv','summary_data')
]
#loop for upload
for csv_file, table_name in csv_files:
    file_path = f'{folder_path}/{csv_file}'


    # Read the CSV
    df = pd.read_csv(file_path)

    
    # Clean column names (replace spaces/special chars)
    df.columns = [col.replace(' ','').replace('-', '').replace('.','_') for col in df.columns]

    
    # Load entire DataFrame into MySQL with one command!
    # if_exists='replace' means it will drop the old table and create a new one.
    # Use if_exists='append' to add data to an existing table.
    df.to_sql(name = table_name, con = engine, if_exists = 'replace', index = False)
    
    
    print(f"Successfully imported {csv_file} to table '{table_name}'.")

print("All done!")
```

    Successfully imported worldometer_coronavirus_daily_data.csv to table 'daily_data'.
    Successfully imported worldometer_coronavirus_summary_data.csv to table 'summary_data'.
    All done!
    


```python
# Making Connection with SQL server.
conn = msc.connect(host = '127.0.0.1',
                   username = 'root',
                   password = 'Vinay@2002',
                   database = 'Covid_19_Database')

cur = conn.cursor() 
```


```python
# Executing data of table daily_data
query = "Select * from daily_data"

cur.execute(query)

data = cur.fetchall()
daily_data = pd.DataFrame(data, columns = ['date', 'country', 'cumulative_total_cases', 'daily_new_cases', 'active_cases', 'cumulative_total_deaths', 'daily_new_deaths'])

print("\n")
# Checking count of null values in each columns
print(daily_data.isnull().sum())
print("\n")
#checking data types
print(daily_data.dtypes)
#Droping the null values from each columns
daily_data = daily_data.dropna()
#changing dtypes to it's actual datatypes
daily_data['date'] = daily_data['date'].astype('datetime64[ns]')
daily_data['cumulative_total_cases'] = daily_data['cumulative_total_cases'].astype('int64')
daily_data['daily_new_cases'] = daily_data['daily_new_cases'].astype('int64')
daily_data['active_cases'] = daily_data['active_cases'].astype('int64')
daily_data['cumulative_total_deaths'] = daily_data['cumulative_total_deaths'].astype('int64')
daily_data['daily_new_deaths'] = daily_data['daily_new_deaths'].astype('int64')

daily_data = daily_data.reset_index()
```

    
    
    date                           0
    country                        0
    cumulative_total_cases         0
    daily_new_cases            10458
    active_cases               18040
    cumulative_total_deaths     6560
    daily_new_deaths           26937
    dtype: int64
    
    
    date                        object
    country                     object
    cumulative_total_cases     float64
    daily_new_cases            float64
    active_cases               float64
    cumulative_total_deaths    float64
    daily_new_deaths           float64
    dtype: object
    


```python
daily_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>date</th>
      <th>country</th>
      <th>cumulative_total_cases</th>
      <th>daily_new_cases</th>
      <th>active_cases</th>
      <th>cumulative_total_deaths</th>
      <th>daily_new_deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10</td>
      <td>2020-02-25</td>
      <td>Afghanistan</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>11</td>
      <td>2020-02-26</td>
      <td>Afghanistan</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12</td>
      <td>2020-02-27</td>
      <td>Afghanistan</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>13</td>
      <td>2020-02-28</td>
      <td>Afghanistan</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>14</td>
      <td>2020-02-29</td>
      <td>Afghanistan</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(f'There are {daily_data.shape[0]} rows and {daily_data.shape[1]} columns in table "daily_data"\nTotal shape of the data is  {daily_data.shape[0] * daily_data.shape[1]}')
```

    There are 142034 rows and 8 columns in table "daily_data"
    Total shape of the data is  1136272
    


```python
# Executing data of table summary_data

query = "Select * from summary_data"

cur.execute(query)

data = cur.fetchall()
summary_data = pd.DataFrame(data, columns = ['country', 'continent', 'total_confirmed', 'total_deaths', 'total_recovered', 'active_cases', 'serious_or_critical', 'total_cases_per_1m_population', 'total_deaths_per_1m_population', 'total_tests', 'total_tests_per_1m_population', 'population'])


print("\n")
# Checking count of null values in each columns
print(summary_data.isnull().sum())
print("\n")
#checking data types
print(summary_data.dtypes)
#Droping the null values from each columns
summary_data = summary_data.dropna()
#changing dtypes to it's actual datatypes
summary_data['total_deaths'] = summary_data['total_deaths'].astype('int64')
summary_data['total_recovered'] = summary_data['total_recovered'].astype('int64')
summary_data['active_cases'] = summary_data['active_cases'].astype('int64')
summary_data['serious_or_critical'] = summary_data['serious_or_critical'].astype('int64')
summary_data['total_deaths_per_1m_population'] = summary_data['total_deaths_per_1m_population'].astype('int64')
summary_data['total_tests'] = summary_data['total_tests'].astype('int64')
summary_data['total_tests_per_1m_population'] = summary_data['total_tests_per_1m_population'].astype('int64')

summary_data = summary_data.reset_index()
```

    
    
    country                            0
    continent                          0
    total_confirmed                    0
    total_deaths                       8
    total_recovered                   22
    active_cases                      22
    serious_or_critical               81
    total_cases_per_1m_population      0
    total_deaths_per_1m_population     8
    total_tests                       14
    total_tests_per_1m_population     14
    population                         0
    dtype: int64
    
    
    country                            object
    continent                          object
    total_confirmed                     int64
    total_deaths                      float64
    total_recovered                   float64
    active_cases                      float64
    serious_or_critical               float64
    total_cases_per_1m_population       int64
    total_deaths_per_1m_population    float64
    total_tests                       float64
    total_tests_per_1m_population     float64
    population                          int64
    dtype: object
    


```python
summary_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>country</th>
      <th>continent</th>
      <th>total_confirmed</th>
      <th>total_deaths</th>
      <th>total_recovered</th>
      <th>active_cases</th>
      <th>serious_or_critical</th>
      <th>total_cases_per_1m_population</th>
      <th>total_deaths_per_1m_population</th>
      <th>total_tests</th>
      <th>total_tests_per_1m_population</th>
      <th>population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>179267</td>
      <td>7690</td>
      <td>162202</td>
      <td>9375</td>
      <td>1124</td>
      <td>4420</td>
      <td>190</td>
      <td>951337</td>
      <td>23455</td>
      <td>40560636</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Albania</td>
      <td>Europe</td>
      <td>275574</td>
      <td>3497</td>
      <td>271826</td>
      <td>251</td>
      <td>2</td>
      <td>95954</td>
      <td>1218</td>
      <td>1817530</td>
      <td>632857</td>
      <td>2871945</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Algeria</td>
      <td>Africa</td>
      <td>265816</td>
      <td>6875</td>
      <td>178371</td>
      <td>80570</td>
      <td>6</td>
      <td>5865</td>
      <td>152</td>
      <td>230861</td>
      <td>5093</td>
      <td>45325517</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Andorra</td>
      <td>Europe</td>
      <td>42156</td>
      <td>153</td>
      <td>41021</td>
      <td>982</td>
      <td>14</td>
      <td>543983</td>
      <td>1974</td>
      <td>249838</td>
      <td>3223924</td>
      <td>77495</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Anguilla</td>
      <td>North America</td>
      <td>2984</td>
      <td>9</td>
      <td>2916</td>
      <td>59</td>
      <td>4</td>
      <td>195646</td>
      <td>590</td>
      <td>51382</td>
      <td>3368870</td>
      <td>15252</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(f'There are {summary_data.shape[0]} rows and {summary_data.shape[1]} columns in table "summary_data"\nTotal shape of the data is {summary_data.shape[0] * summary_data.shape[1]}')
```

    There are 131 rows and 13 columns in table "summary_data"
    Total shape of the data is 1703
    

**1. What are the top 5 countries with the highest total confirmed COVID-19 cases?**


```python
query = """SELECT country, continent,
SUM(total_confirmed) as Total_confirm
FROM summary_data
GROUP BY country, continent
ORDER BY Total_confirm DESC;"""

cur.execute(query)

data = cur.fetchall()
top_5 = pd.DataFrame(data, columns = ['Country','Continent', 'Total_confirm']).head()

```


```python
plt.figure(figsize = (8,5))
plt.style.use('ggplot')
rank = sns.barplot(data = top_5, x = 'Country', y = 'Total_confirm', edgecolor = 'black', linewidth = 2, hue = 'Continent', palette = 'Reds_r')

plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.title("The top 5 countries with the highest total confirmed COVID-19 cases", fontweight = 'bold', fontsize = 14)
plt.xlabel('Country', fontweight = 'bold')
plt.ylabel('Total_confirm', fontweight = 'bold')

plt.tight_layout()
plt.show()
```


    
![png](output_11_0.png)
    



```python
top_5
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Continent</th>
      <th>Total_confirm</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>North America</td>
      <td>84209473</td>
    </tr>
    <tr>
      <th>1</th>
      <td>India</td>
      <td>Asia</td>
      <td>43121599</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Brazil</td>
      <td>South America</td>
      <td>30682094</td>
    </tr>
    <tr>
      <th>3</th>
      <td>France</td>
      <td>Europe</td>
      <td>29160802</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Germany</td>
      <td>Europe</td>
      <td>25780226</td>
    </tr>
  </tbody>
</table>
</div>



**2 .Which continent has the highest total deaths due to COVID-19?**


```python
query = """SELECT continent,
SUM(total_deaths) as Total_Death
FROM summary_data
GROUP BY continent
ORDER BY Total_Death DESC"""

cur.execute(query)

data = cur.fetchall()
highest_death = pd.DataFrame(data, columns = ['Continent', 'Total Death'])

```


```python
plt.figure(figsize = (9,6))
plt.style.use('bmh')
sns.barplot(data = highest_death, x = 'Continent', y = 'Total Death', edgecolor = 'black', linewidth = 2, palette = 'viridis')

plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.title("Continent has the highest total deaths due to COVID-19", fontweight = 'bold', fontsize = 14)
plt.xlabel('Total Death', fontweight = 'bold')
plt.ylabel('Total_confirm', fontweight = 'bold')


# plt.savefig("Continent-wise COVID-19 Mortality.png", dpi = 300, bbox_inches = 'tight')
plt.tight_layout()
plt.show()
```


    
![png](output_15_0.png)
    



```python
highest_death
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Continent</th>
      <th>Total Death</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Europe</td>
      <td>1830655.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>North America</td>
      <td>1467234.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Asia</td>
      <td>1427939.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>South America</td>
      <td>1296523.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Africa</td>
      <td>254319.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Australia/Oceania</td>
      <td>11413.0</td>
    </tr>
  </tbody>
</table>
</div>



**3. What is the relationship between total tests conducted and total confirmed cases for different countries?**


```python
df_clean = summary_data.dropna(subset = ['total_tests', 'total_confirmed'])
```


```python
correlatio_3 = df_clean['total_tests'].corr(df_clean['total_confirmed'])

```


```python
print(f'Correlation between total tests conducted and total confirmed cases: {correlatio_3:.3f}')

plt.figure(figsize = (9,6))
sns.scatterplot(data = df_clean, x = 'total_tests',y = 'total_confirmed',edgecolor = 'black',  s = 90, color = '#bc0c1c', alpha = 0.7)


plt.title('Total Tests Conducted vs Total Confirmed Cases' , fontweight='bold', fontsize=14)
plt.xlabel('Total Tests Conducted' , fontweight='bold')
plt.ylabel('Total Confirmed Cases' , fontweight='bold')
plt.grid(True)
plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.gca().xaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))


# plt.savefig("Image_3.png", dpi = 300, bbox_inches = 'tight')

plt.tight_layout()
plt.show()

```

    Correlation between total tests conducted and total confirmed cases: 0.889
    


    
![png](output_20_1.png)
    


**4. Calculate the death rate (total deaths/total confirmed cases) for each country; which country has the highest death rate?**


```python
query = """SELECT country,
total_deaths as Total_Death, 
total_confirmed as Total_Confirmed,
(CAST(total_deaths AS FLOAT) / CAST(total_confirmed AS FLOAT)) AS Death_ratio

FROM summary_data
ORDER BY Death_ratio DESC"""

cur.execute(query)

data = cur.fetchall()
Total_death = pd.DataFrame(data, columns = ['Country','Total_Death', 'Total_Confirmed', 'Death_ratio']).head(10)
Total_death = Total_death.sort_values('Death_ratio' , ascending = False)
Total_death
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total_Death</th>
      <th>Total_Confirmed</th>
      <th>Death_ratio</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Yemen</td>
      <td>2149.0</td>
      <td>11819</td>
      <td>0.181826</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Western Sahara</td>
      <td>1.0</td>
      <td>10</td>
      <td>0.100000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sudan</td>
      <td>4936.0</td>
      <td>62161</td>
      <td>0.079407</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Peru</td>
      <td>213023.0</td>
      <td>3571919</td>
      <td>0.059638</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Mexico</td>
      <td>324465.0</td>
      <td>5745652</td>
      <td>0.056471</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Syria</td>
      <td>3150.0</td>
      <td>55869</td>
      <td>0.056382</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Somalia</td>
      <td>1350.0</td>
      <td>26518</td>
      <td>0.050909</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Egypt</td>
      <td>24613.0</td>
      <td>515645</td>
      <td>0.047732</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Afghanistan</td>
      <td>7690.0</td>
      <td>179267</td>
      <td>0.042897</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Bosnia And Herzegovina</td>
      <td>15778.0</td>
      <td>377511</td>
      <td>0.041795</td>
    </tr>
  </tbody>
</table>
</div>




```python
colors = ["crimson"] + ["steelblue"] * 9

plt.figure(figsize = (9,6))


plt.barh(y = Total_death['Country'], width = Total_death['Death_ratio'], color = colors, edgecolor = 'black', linewidth = 2)


plt.title("Countries with the Highest COVID-19 Death Rate", fontweight='bold', fontsize=14)
plt.xlabel('Death Rate (Total Deaths / Total Confirmed Cases)', fontweight='bold')
plt.ylabel('Country', fontweight='bold')
plt.gca().invert_yaxis()


# plt.savefig("Image_2.png", dpi = 300, bbox_inches = 'tight')

plt.tight_layout()
plt.show()

```


    
![png](output_23_0.png)
    


**5 . Identify the country with the most active COVID-19 cases on the latest date in the daily data.**


```python
query = """
WITH LatestDate AS(
	SELECT MAX(date) AS latest_date
	FROM daily_data
	),

LatestActiveCASE AS(
	SELECT 	daily_data.country AS Country,
			daily_data.active_cases AS Active_Cases,
			DATE_FORMAT(daily_data.date, "%D - %M - %Y") AS Latest_Case

	FROM daily_data
	JOIN LatestDate
	ON daily_data.date = LatestDate.latest_date
    )

SELECT * FROM LatestActiveCASE
ORDER BY Active_Cases DESC
LIMIT 10;
"""
cur.execute(query)
data = cur.fetchall()
latest_active = pd.DataFrame(data, columns=['Country','Active_cases', 'Latest_cases'])

#changing datatype of column 'Active Case' by float into intger.
latest_active['Active_cases'] = latest_active['Active_cases'].astype('int64')
```


```python
plt.figure(figsize = (9,6))
# plt.style.use('bmh')
sns.lineplot(data = latest_active, x = 'Country', y = 'Active_cases',palette = 'viridis', mfc = 'yellow',mec = 'black',linestyle = '-', linewidth = 2, marker = 'o' , hue = 'Latest_cases', ms = 9)

plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.title("The country with the most active COVID-19 cases on the latest date in the daily data.", fontweight = 'bold', fontsize = 13)
plt.xlabel('Country', fontweight = 'bold')
plt.ylabel('Active Cases', fontweight = 'bold')
plt.gca().invert_xaxis()


plt.tight_layout()
plt.show()


```


    
![png](output_26_0.png)
    



```python
latest_active
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Active_cases</th>
      <th>Latest_cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>1938567</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Germany</td>
      <td>1711202</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Viet Nam</td>
      <td>1302379</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Italy</td>
      <td>1001352</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>4</th>
      <td>France</td>
      <td>856871</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Taiwan</td>
      <td>652582</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Poland</td>
      <td>551990</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Spain</td>
      <td>473589</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Australia</td>
      <td>391667</td>
      <td>14th - May - 2022</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Mexico</td>
      <td>376294</td>
      <td>14th - May - 2022</td>
    </tr>
  </tbody>
</table>
</div>



**6. How has the daily number of new COVID-19 cases trended over time for specific countries (e.g., USA, India, Brazil)?**


```python
query = """SELECT Country,
date(date) as Latest_Date,
daily_new_cases as daily_new_cases

From daily_data
where country IN ("brazil", "India", "USA")

ORDER BY Country,Latest_Date DESC;
"""
cur.execute(query)
data = cur.fetchall()
new_cases = pd.DataFrame(data, columns=['Country','Latest_Date', 'Daily_new_cases'])

# Changing datatype of column 'Latest_Date' from object to datetime.
new_cases['Latest_Date'] = new_cases['Latest_Date'].astype('datetime64[ns]')

# Droping null values from column 'Daily_new_cases'
new_cases = new_cases.dropna()
new_cases['Daily_new_cases'] = new_cases['Daily_new_cases'].astype('int64')
```


```python
plt.figure(figsize = (14,6))
plt.style.use("bmh")
sns.lineplot(data = new_cases, x = 'Latest_Date', y = 'Daily_new_cases', 
             palette = 'dark',
             mec = 'black',
             linewidth = 2,
             hue = 'Country',
             ms = 9)

plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.title('Daily New COVID-19 Cases Trend (USA, India, Brazil)', fontweight='bold', fontsize=17)
plt.xlabel('Date', fontweight='bold', fontsize = 15)
plt.ylabel('Daily New Cases', fontweight='bold',fontsize = 15)
plt.legend(title = "Country" , fontsize = 16)



plt.tight_layout()
plt.show()

```


    
![png](output_30_0.png)
    



```python
new_cases
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Latest_Date</th>
      <th>Daily_new_cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Brazil</td>
      <td>2022-05-14</td>
      <td>17355</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Brazil</td>
      <td>2022-05-13</td>
      <td>25609</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Brazil</td>
      <td>2022-05-12</td>
      <td>21344</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Brazil</td>
      <td>2022-05-11</td>
      <td>23398</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Brazil</td>
      <td>2022-05-10</td>
      <td>20143</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2454</th>
      <td>USA</td>
      <td>2020-02-20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2455</th>
      <td>USA</td>
      <td>2020-02-19</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2456</th>
      <td>USA</td>
      <td>2020-02-18</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2457</th>
      <td>USA</td>
      <td>2020-02-17</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2458</th>
      <td>USA</td>
      <td>2020-02-16</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>2447 rows × 3 columns</p>
</div>



**7. Analyze the correlation between population size and total recovered cases across countries.**


```python
correlation = summary_data['population'].corr(summary_data['total_recovered'])
```


```python
query = """SELECT Country,
population as Population,
total_recovered as Total_recovered
FROM summary_data
WHERE Population is not null AND total_recovered is not null AND Population > 0 AND Total_recovered > 0;
"""
cur.execute(query)
data = cur.fetchall()
c_df = pd.DataFrame(data, columns=['Country','Population', 'Total_Recovered'])
c_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Population</th>
      <th>Total_Recovered</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>40560636</td>
      <td>162202.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>2871945</td>
      <td>271826.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Algeria</td>
      <td>45325517</td>
      <td>178371.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Andorra</td>
      <td>77495</td>
      <td>41021.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Angola</td>
      <td>34769277</td>
      <td>97149.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(f'The correlation between population size and total recovered cases across countries. {correlation:.3f}')

plt.figure(figsize = (10,8))
sns.set_style("whitegrid")
sns.scatterplot(data = c_df, x= 'Population', y= 'Total_Recovered',color = 'green', edgecolor = "k", s = 90, linewidth = 1, alpha = 0.7)


plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.02f}'))
plt.gca().xaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.02f}'))
plt.title('Population Size vs Total Recovered Cases', fontweight='bold', fontsize=14)
plt.xlabel('Population', fontweight='bold')
plt.ylabel('Total Recovered Cases', fontweight='bold')

plt.xticks(rotation = 45)


# plt.savefig("Image_4.png", dpi = 300, bbox_inches = 'tight')
plt.tight_layout()
plt.show()
```

    The correlation between population size and total recovered cases across countries. 0.411
    


    
![png](output_35_1.png)
    


**8. Compare the rate of increase of total cases and deaths between continents over time.**


```python
query = """
SELECT summary_data.continent as Continent,
SUM(daily_data.cumulative_total_cases) as Total_cases,
SUM(daily_data.cumulative_total_deaths) as Total_deaths,
Date_Format(daily_data.date, "%D - %M - %Y") as Over_time

FROM daily_data
JOIN summary_data
ON daily_data.country = summary_data.country

GROUP BY Continent, daily_data.date
ORDER BY Continent,daily_data.date;
"""
cur.execute(query)

data = cur.fetchall()
Inc_rate = pd.DataFrame(data, columns = ['Continent','Total_cases', 'Total_deaths', 'Over_time'])


#Changing DataType
Inc_rate['Total_cases'] = Inc_rate['Total_cases'].astype('int64')
Inc_rate['Total_deaths'] = Inc_rate['Total_deaths'].astype('int64')

Inc_rate.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Continent</th>
      <th>Total_cases</th>
      <th>Total_deaths</th>
      <th>Over_time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Africa</td>
      <td>1513641</td>
      <td>37205</td>
      <td>1st - October - 2020</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Africa</td>
      <td>1522719</td>
      <td>37350</td>
      <td>2nd - October - 2020</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Africa</td>
      <td>1531643</td>
      <td>37464</td>
      <td>3rd - October - 2020</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Africa</td>
      <td>1539816</td>
      <td>37649</td>
      <td>4th - October - 2020</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Africa</td>
      <td>1544835</td>
      <td>37779</td>
      <td>5th - October - 2020</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize = (14,6))
plt.style.use("bmh")
sns.lineplot(data = Inc_rate, x = 'Total_cases', y = 'Total_deaths', 
             palette = 'dark',
             mec = 'black',
             linewidth = 2,
             hue = 'Continent',
             ms = 9)

plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.gca().xaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))

plt.title(' The rate of increase of total cases and deaths between continents over time.', fontweight='bold', fontsize=16)
plt.xlabel('Total cases', fontweight='bold', fontsize= 12)
plt.ylabel('Total Deaths', fontweight='bold', fontsize= 12)
plt.legend(title = "Continent", loc = 'lower right', fontsize = 13)



# plt.savefig("Image_5.png", dpi = 300, bbox_inches = 'tight')
plt.tight_layout()
plt.show()

```


    
![png](output_38_0.png)
    


**9. Using principal component analysis (PCA), identify key features influencing the COVID-19 impact metrics in the summary dataset.**



```python
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
```


```python
query = """
SELECT country,
total_confirmed,
total_deaths,
total_recovered,
active_cases,
serious_or_critical,
total_cases_per_1m_population,
total_deaths_per_1m_population,
total_tests,
total_tests_per_1m_population,
population

FROM summary_data
WHERE total_confirmed IS NOT NULL AND total_deaths IS NOT NULL AND total_recovered IS NOT NULL ;
"""
cur.execute(query)

data = cur.fetchall()
Df = pd.DataFrame(data, columns = ['Country', 'Total_confirmed', 'Total_deaths', 'Total_recovered', 'Active_cases', 'Serious_or_critical', 'Total_cases_per_1m_population', 'Total_deaths_per_1m_population', 'Total_tests', 'Total_tests_per_1m_population', 'Population'])

# Drop Non-numeric column
num_df = Df.drop('Country', axis = 1).dropna()

#Standardize features
scaler = StandardScaler()
scaled_data = scaler.fit_transform(num_df)

#Perform PCA
pca = PCA(n_components = 3)
principal_components =  pca.fit_transform(scaled_data)

# Loading Features
Loading = pd.DataFrame(
    pca.components_.T,
    columns = ["PC 1","PC 2","PC 3"],
    index = num_df.columns)
    
```


```python
print("Explained variance by each principal component:")
print(pca.explained_variance_ratio_)
print("\nFeature Loading on the first three principal components:")
Loading = Loading.abs()
print(Loading)


plt.figure(figsize = (12,7))
plt.barh(Loading.index, Loading['PC 1'], color = 'violet', edgecolor = 'k', linewidth = 2)


plt.title('Key Features Influencing PC1 (COVID-19 Impact)')
plt.xlabel('Absolute Loading Value', fontweight = "bold", fontsize = 12)

plt.tight_layout()
plt.show()

```

    Explained variance by each principal component:
    [0.47894835 0.19837523 0.10706297]
    
    Feature Loading on the first three principal components:
                                        PC 1      PC 2      PC 3
    Total_confirmed                 0.448172  0.007856  0.035323
    Total_deaths                    0.431772  0.079314  0.160255
    Total_recovered                 0.447646  0.009361  0.041392
    Active_cases                    0.335809  0.075698  0.088698
    Serious_or_critical             0.257584  0.131729  0.530361
    Total_cases_per_1m_population   0.049072  0.639547  0.058208
    Total_deaths_per_1m_population  0.130004  0.430673  0.451478
    Total_tests                     0.405425  0.009021  0.351851
    Total_tests_per_1m_population   0.045466  0.535811  0.393558
    Population                      0.217866  0.297997  0.443057
    


    
![png](output_42_1.png)
    


**Dash Board : COVID-19 Dashboard Overview**


```python
from matplotlib.gridspec import GridSpec
```


```python
fig = plt.figure(constrained_layout =True, figsize= (18,14))
gs = GridSpec(3,2, figure = fig)

sns.set_style("whitegrid")

plt.suptitle("COVID-19 Dashboard Overview", fontweight = 'bold', fontsize = 20)
fig.patch.set_facecolor('lavender')

# Plot 1 : - Continent has the highest total deaths

ax1 = fig.add_subplot(gs[0,0])
sns.barplot(data = highest_death, x = 'Continent', y = 'Total Death', edgecolor = 'black', linewidth = 2, palette = 'coolwarm_r')

plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
ax1.set_title("Continent has the highest total deaths due to COVID-19", fontweight = 'bold', fontsize = 14)
ax1.set_xlabel('Total Death', fontweight = 'bold')
ax1.set_ylabel('Total_confirm', fontweight = 'bold')


# Plot 2 :-Countries with the Highest COVID-19 Death Rate

ax2 = fig.add_subplot(gs[0,1])
plt.barh(Total_death['Country'],Total_death['Death_ratio'], color = colors, edgecolor = 'black', linewidth = 2)

ax2.set_title("Countries with the Highest COVID-19 Death Rate", fontweight='bold', fontsize=14)
ax2.set_xlabel('Death Rate (Total Deaths / Total Confirmed Cases)', fontweight='bold')
ax2.set_ylabel('Country', fontweight='bold')
plt.gca().invert_yaxis()



#Plot 3 :- Tests Conducted vs Total Confirmed Cases

ax3 = fig.add_subplot(gs[1,0])
sns.scatterplot(data = df_clean, x = 'total_tests',y = 'total_confirmed',edgecolor = 'black',  s = 90, color = '#bc0c1c', alpha = 0.7)

ax3.set_title('Total Tests Conducted vs Total Confirmed Cases' , fontweight='bold', fontsize=14)
ax3.set_xlabel('Total Tests Conducted' , fontweight='bold')
ax3.set_ylabel('Total Confirmed Cases' , fontweight='bold')
ax3.grid(True)
plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.gca().xaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))



# Plot 4 :- Population Size vs Total Recovered Cases

ax4 = fig.add_subplot(gs[1,1])
sns.scatterplot(data = c_df, x= 'Population', y= 'Total_Recovered',color = 'green', edgecolor = "k", s = 90, linewidth = 1, alpha = 0.7)


plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.02f}'))
plt.gca().xaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.02f}'))
ax4.set_title('Population Size vs Total Recovered Cases', fontweight='bold', fontsize=14)
ax4.set_xlabel('Population', fontweight='bold')
ax4.set_ylabel('Total Recovered Cases', fontweight='bold')
plt.xticks(rotation = 35)



# plot 5 :- Rate of increase of total cases and deaths
ax5 = fig.add_subplot(gs[2,:])

sns.lineplot(data = Inc_rate, x = 'Total_cases', y = 'Total_deaths', 
             palette = 'dark',
             mec = 'black',
             linewidth = 2,
             hue = 'Continent',
             ms = 9)

plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.gca().xaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))

ax5.set_title(' The rate of increase of total cases and deaths between continents over time.', fontweight='bold', fontsize=16)
ax5.set_xlabel('Total cases', fontweight='bold', fontsize= 12)
ax5.set_ylabel('Total Deaths', fontweight='bold', fontsize= 12)
ax5.legend(title = "Continent", loc = 'lower right', fontsize = 13)


# plt.savefig("COVID-19 Dashboard Overview.png", dpi = 300, bbox_inches = 'tight')
plt.tight_layout()
plt.show()
```


    
![png](output_45_0.png)
    



```python
conn.commit()
conn.close()
```


```python

```
